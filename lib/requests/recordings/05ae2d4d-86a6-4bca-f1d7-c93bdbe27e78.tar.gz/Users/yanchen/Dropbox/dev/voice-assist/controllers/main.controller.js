module.exports = function(app) {
	var _ = require('underscore');

	app.controller("MainController", ['$scope', 'ServerQuery', function ($scope, ServerQuery) {
		
	}]);
};
