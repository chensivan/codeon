#Voice Assist

A plugin for the [atom.io](https://atom.io) code editor. To install, first ensure [node.js](https://nodejs.org) is installed.

After cloning this repository, run `npm install .` in the repository directory to install dependencies.

Then, create a symlink to this repository under the ~/.atom/packages directory:
```
ln -s /path/to/this/repo ~/.atom/packages/voice-assist
```
