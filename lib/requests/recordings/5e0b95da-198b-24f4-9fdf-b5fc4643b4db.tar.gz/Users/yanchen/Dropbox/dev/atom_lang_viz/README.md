#Atom Language Viz.

A plugin for the [atom.io](https://atom.io) code editor.

After cloning this repository, run `npm install .` in the repository directory to install dependencies.

Then, create a symlink to this repository under the ~/.atom/packages directory.

On a Mac/Unix-based machine:
```
ln -s /absolute/path/to/this/repo ~/.atom/packages/atom-lang-viz
node dummy_server.js
```

Look at package settings -> server URL to change the server URL