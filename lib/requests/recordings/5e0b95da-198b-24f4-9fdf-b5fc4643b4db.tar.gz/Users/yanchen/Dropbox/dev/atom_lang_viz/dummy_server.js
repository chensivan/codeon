var express = require('express');
var app = express();

app.get('/sampleCode', function (req, res) {
	var query = req.query;

	res.json({
		examples: [
			{
				description: 'example 1',
				code: 'function() {\nreturn 1+1;\n}',
				origin: 'http://www.umich.edu/'
			}, {
				description: 'example 2',
				code: 'function() {\nreturn 2+2;\n}',
				origin: 'http://www.cmu.edu/'
			}
		]
	});
});

app.listen(3000);
console.log('Dummy data server running on port 3000');